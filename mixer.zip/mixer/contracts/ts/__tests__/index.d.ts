declare var accounts: any[]
declare var utils: any
//declare var assert: any
//declare var before: any
//declare var it: any
//declare var describe: any
