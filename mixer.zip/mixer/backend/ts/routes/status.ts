const backendStatus = async () => {
}

export default backendStatus
