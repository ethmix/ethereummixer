#!/bin/bash

cp ../semaphore/semaphorejs/build/verification_key.json ./
